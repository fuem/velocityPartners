"use strict";
//var Customer = require('./models/Customer.js');
//var Invoice  = require('./models/Invoice.js');

var modulo = require('./models/Invoice');
modulo.say();
console.log(modulo.message);
modulo.Producto;
console.log("apps")

//var Product  = require('./models/Product.js');
//var Json = require('./data/data.json'); 

//var customer = Json["customers"];

//var cust = Customer.createFake(Json["customers"][0]);

//var products_size = Json["products"].length;
//var products = Json["products"];
//var actualizar = Invoice.Producto();
/*for (var i = products_size; i >= 0; i--) {
    products.push(Product.createFake());
};*/

//console.log(Json["customers"][0]["email"]);
//console.log(Invoice.Address);