//var faker    = require('faker');
//var UUID = require('uuid-js');
//var Json = require('../data/data.json');/**/
//function producto(){
//	console.log("hola")
	//return 5;
	//this.stock = stock | 100;
//}

//Producto.prototype.updateStock = updateStock;

/*function updateStock(value){
	return 5;
	if(this.stock >= value){
		this.stock = this.stock - value;
	}else{
		thro}
};*/
//module.exports=producto;




var invisible = function () {
  console.log("invisible");
}
exports.message = "hi";
exports.say = function () {
  console.log("message");
}
function producto(){
	console.log("producto");
}
exports=producto();

/*
module.exports = (function(){
	'use strict';

	//createdAt, updatedAt, customerId, items[{product: Product, quantity: number}]
	var Invoice = function(data){
		var self = this;
		//self.id = data.id || UUID.create(4).hex;
		self.createdAt = data.createdAt;
		self.updatedAt = data.updatedAt;
		self.customerId = data.customerId;
		self.items = data.items || [];
	};
	Invoice.prototype.add = function(product, quantity){
		var self = this;
		self.items.push({
			product: product,
			quantity: quantity
		});
	};
	
	Invoice.prototype.register = function(){

	};

	return Invoice;
})();*/