/*var init=4;
var counter=(function(n){
return{
	count:function(){console.log(n); n += +1},
	reset:function(){n = 0}
	};
})(init);*/
/*
module.exports = (function(){
	var Customer = function(data){
		return 5
	}
	return cut=Customer;
})
*/



/***************************/
/*function Producto(){};
	Producto.prototype.updateStock = updateStock;
	function updateStock(value){
		if(this.stock => value){
			this.stock = this.stock.value;
		}
	//this.stock

} 
module.exports = Producto;*/
/****************************/
/*function Customer(){};
	Producto.prototype.updateStock = updateStock;
	function updateStock(value){
		if(this.stock => value){
			this.stock = this.stock.value;
		}
	//this.stock

} 
module.exports = Customer;*/

//var faker    = require('faker');
//var UUID = require('uuid-js');

/*module.exports = (function(){
	'use strict';

	//Customers ( email, name, phone, address )
	var Customer = function(data){
		//this.id = data.id || UUID.create(4).hex;
		this.email = data.email;
		this.name = data.name;
		this.phone = data.phone;
		this.address = data.address;
	};

	Customer.createFake = function(){
		return new Customer({
			name: data.name,//faker.name.findName(),
			phone: data.phone,//faker.phone.phoneNumber(),
			email: data.email,//faker.internet.email(),
			address: data.address,//faker.address.streetAddress()+" "+faker.address.secondaryAddress()
		});
	};
	return Customer;
})();*/