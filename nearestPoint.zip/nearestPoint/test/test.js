var chai = require('chai'),
	nearestPoint=require("../lib/nearestPoint.js"),
	referencia=[0,5],
	points=[[100,1],[33,8],[30,41],[73,18],[-10,0],[-3,-2],[73,18],[0,5],[1,5],[0,4]],
	assert=chai.assert;

describe('Prueba medir distancias con respecto a un referente', function(){
	it('Prueba de comparacion de numero menor', function(){
		assert.equal(nearestPoint.comparator(6,7),true)
		});
	it('Prueba de comparacion de distancia menor', function(){
		assert.equal(nearestPoint.defineNearest(referencia,points),0)
		});
	it('Prueba de captura de arreglo con la informacion de las coordenadas', function(){
		assert.equal(nearestPoint.savePositionInfo(0,7,points),5)
		});
	
});